
  # 桌游地图设计

  This is a code bundle for 桌游地图设计. The original project is available at https://www.figma.com/design/GuGKlRRGSoWl3kFkXnhuxN/%E6%A1%8C%E6%B8%B8%E5%9C%B0%E5%9B%BE%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  