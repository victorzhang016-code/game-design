import { BoardGame } from "./components/BoardGame";

export default function App() {
  return <BoardGame />;
}